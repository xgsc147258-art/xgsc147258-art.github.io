import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Home, Users, Shield, LayoutGrid, FolderOpen, Bookmark, Zap, Settings } from 'lucide-react';
import HomePage from './pages/Home';
import Collaboration from './pages/Collaboration';
import Purifier from './pages/Purifier';
import Workspace from './pages/Workspace';
import Projects from './pages/Projects';
import Library from './pages/Library';
import Recharge from './pages/Recharge';
import { LoginModal } from './components/LoginModal';

const sidebarItems = [
  { id: 'home', icon: Home, label: '首页' },
  { id: 'collab', icon: Users, label: '协作台' },
  { id: 'purifier', icon: Shield, label: '净化器' },
  { id: 'workspace', icon: LayoutGrid, label: '工作区' },
  { id: 'projects', icon: FolderOpen, label: '项目' },
  { id: 'library', icon: Bookmark, label: '词库' },
  { id: 'recharge', icon: Zap, label: '充值' },
  { id: 'settings', icon: Settings, label: '设置' },
];

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [username, setUsername] = useState('林金达');

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return <HomePage />;
      case 'collab':
        return <Collaboration />;
      case 'purifier':
        return <Purifier />;
      case 'workspace':
        return <Workspace />;
      case 'projects':
        return <Projects />;
      case 'library':
        return <Library />;
      case 'recharge':
        return <Recharge />;
      case 'settings':
        return (
          <div className="flex-1 p-8">
            <h1 className="text-2xl font-bold text-gray-900 mb-6">设置</h1>
            <div className="max-w-2xl">
              <div className="bg-white rounded-xl border border-gray-200 p-6 mb-4">
                <h3 className="font-semibold text-gray-900 mb-4">账号设置</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">用户名</span>
                    <span className="text-gray-900">{username}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">账号绑定</span>
                    <span className="text-green-500">已绑定微信</span>
                  </div>
                </div>
              </div>
              <div className="bg-white rounded-xl border border-gray-200 p-6">
                <h3 className="font-semibold text-gray-900 mb-4">偏好设置</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">深色模式</span>
                    <button className="w-12 h-6 bg-gray-200 rounded-full relative transition-colors">
                      <span className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full shadow"></span>
                    </button>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">通知提醒</span>
                    <button className="w-12 h-6 bg-yellow-400 rounded-full relative transition-colors">
                      <span className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full shadow"></span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      default:
        return <HomePage />;
    }
  };

  const isDarkPage = activeTab === 'purifier' || activeTab === 'workspace';

  return (
    <div className={`flex h-screen ${isDarkPage ? 'bg-[#1a1a1a]' : 'bg-gray-50'}`}>
      {/* Sidebar */}
      <div className={`w-20 border-r flex flex-col items-center py-4 fixed left-0 top-0 h-full z-50 ${isDarkPage ? 'bg-[#1a1a1a] border-gray-800' : 'bg-white border-gray-200'}`}>
        <div className="mb-6">
          <div className="w-10 h-10 flex items-center justify-center">
            <img src={new URL('../assets/画板_1.png', import.meta.url).href} alt="小憨熊" className="w-10 h-10 object-contain" />
          </div>
        </div>
        <nav className="flex flex-col gap-1 w-full px-2">
          {sidebarItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <motion.button
                key={item.id}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveTab(item.id)}
                className={`flex flex-col items-center justify-center py-3 px-2 rounded-xl transition-all duration-200 ${
                  isActive
                    ? 'bg-yellow-400 text-black shadow-lg shadow-yellow-400/30'
                    : isDarkPage
                    ? 'text-gray-400 hover:bg-gray-800 hover:text-gray-200'
                    : 'text-gray-500 hover:bg-gray-100 hover:text-gray-700'
                }`}
              >
                <Icon size={20} />
                <span className="text-xs mt-1 font-medium">{item.label}</span>
              </motion.button>
            );
          })}
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col ml-20">
        {/* Header */}
        {!isDarkPage && (
          <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 fixed top-0 left-20 right-0 z-40">
            <div className="flex items-center gap-2">
              <span className="font-bold text-lg text-gray-900">TechLab.AI</span>
            </div>
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Zap size={16} className="text-yellow-500" />
                <div className="w-20 h-2 bg-gray-200 rounded-full">
                  <div className="w-3/4 h-full bg-yellow-400 rounded-full"></div>
                </div>
                <span>1800 算力</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <LayoutGrid size={16} />
                <span>-- 天</span>
              </div>
              {isLoggedIn ? (
                <>
                  <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                    <svg viewBox="0 0 24 24" className="w-5 h-5 text-gray-500" fill="currentColor">
                      <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                    </svg>
                  </div>
                  <span className="text-sm text-gray-700">{username}</span>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="px-4 py-2 bg-black text-white rounded-full text-sm font-medium"
                  >
                    升级 Pro
                  </motion.button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => setIsLoginOpen(true)}
                    className="text-sm text-gray-700 hover:text-black"
                  >
                    登录
                  </button>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="px-4 py-2 bg-black text-white rounded-full text-sm font-medium"
                  >
                    升级 Pro
                  </motion.button>
                </>
              )}
            </div>
          </header>
        )}

        {/* Content */}
        <main className={`flex-1 overflow-auto ${isDarkPage ? '' : 'pt-16'}`}>
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="h-full"
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Login Modal */}
      <LoginModal isOpen={isLoginOpen} onClose={() => setIsLoginOpen(false)} />
    </div>
  );
}
