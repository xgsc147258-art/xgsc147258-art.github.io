import React from 'react';
import { Folder, MoreVertical } from 'lucide-react';

const projects = [
  { id: 1, name: '未命名项目', updatedAt: '2024-01-15', thumbnail: null },
  { id: 2, name: '现代客厅设计', updatedAt: '2024-01-14', thumbnail: null },
  { id: 3, name: '日式茶室方案', updatedAt: '2024-01-13', thumbnail: null },
];

export default function Projects() {
  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold text-gray-900">项目</h1>
        <button className="px-4 py-2 bg-yellow-400 text-black rounded-lg font-medium hover:bg-yellow-500 transition-colors">
          新建项目
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {projects.map((project) => (
          <div
            key={project.id}
            className="group bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
          >
            <div className="aspect-video bg-gray-100 flex items-center justify-center">
              {project.thumbnail ? (
                <img
                  src={project.thumbnail}
                  alt={project.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <Folder className="w-12 h-12 text-gray-300" />
              )}
            </div>
            <div className="p-4">
              <div className="flex items-center justify-between">
                <h3 className="font-medium text-gray-900 truncate">
                  {project.name}
                </h3>
                <button className="p-1 hover:bg-gray-100 rounded">
                  <MoreVertical className="w-4 h-4 text-gray-400" />
                </button>
              </div>
              <p className="text-sm text-gray-500 mt-1">
                更新于 {project.updatedAt}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
