import React, { useState } from 'react';
import { ArrowLeft, Save, Zap, MessageSquare, Users, Sparkles, Paperclip } from 'lucide-react';

const Workspace: React.FC = () => {
  const [activeTab, setActiveTab] = useState('创作');
  const [resolution, setResolution] = useState('2K');

  const tabs = ['创作', '协作', '对话'];
  const colorLabels = [
    { color: 'bg-yellow-400', label: '参考图' },
    { color: 'bg-green-400', label: '已确认方案' },
    { color: 'bg-blue-400', label: '同一项目区域' },
    { color: 'bg-orange-400', label: '需要修改' },
    { color: 'bg-purple-400', label: '客户偏好' },
  ];

  return (
    <div className="h-screen bg-[#1a1a1a] flex flex-col">
      {/* Top Bar */}
      <div className="h-14 bg-[#1a1a1a] border-b border-gray-800 flex items-center justify-between px-4">
        <div className="flex items-center gap-4">
          <button className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors">
            <ArrowLeft size={18} />
            <span className="text-sm">返回</span>
          </button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-black rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xs">TL</span>
            </div>
            <span className="text-white font-medium">TechLab.AI</span>
          </div>
        </div>
        <div className="text-white font-medium">未命名项目</div>
        <div className="flex items-center gap-4">
          <button className="flex items-center gap-2 bg-yellow-500 text-black px-3 py-1.5 rounded-lg text-sm font-medium hover:bg-yellow-400 transition-colors">
            <Save size={16} />
            保存
          </button>
          <div className="flex items-center gap-2 text-gray-400">
            <Zap size={16} className="text-yellow-500" />
            <div className="w-20 h-2 bg-gray-700 rounded-full">
              <div className="w-3/4 h-full bg-yellow-500 rounded-full"></div>
            </div>
            <span className="text-sm">-- 算力</span>
          </div>
          <button className="bg-gray-700 text-white px-4 py-1.5 rounded-lg text-sm hover:bg-gray-600 transition-colors">
            登录
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex">
        {/* Canvas Area */}
        <div className="flex-1 relative bg-[#1a1a1a]">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-gray-600 text-sm">输入提示词，开始生成空间图像</div>
          </div>
          
          {/* Color Labels */}
          <div className="absolute bottom-4 left-4 flex flex-col gap-2">
            <div className="text-gray-500 text-xs mb-1">颜色标记</div>
            {colorLabels.map((item, index) => (
              <div key={index} className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${item.color}`}></div>
                <span className="text-gray-400 text-xs">{item.label}</span>
              </div>
            ))}
          </div>

          {/* Zoom Controls */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-gray-800 rounded-lg px-3 py-1">
            <button className="text-gray-400 hover:text-white text-sm">-</button>
            <span className="text-white text-sm">100%</span>
            <button className="text-gray-400 hover:text-white text-sm">+</button>
          </div>
        </div>

        {/* Right Sidebar */}
        <div className="w-80 bg-[#1a1a1a] border-l border-gray-800 flex flex-col">
          {/* Tabs */}
          <div className="flex gap-2 p-4">
            {tabs.map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-colors ${
                  activeTab === tab
                    ? 'bg-gray-700 text-white'
                    : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Chat Area */}
          <div className="flex-1 p-4 overflow-y-auto">
            <div className="bg-gray-800 rounded-lg p-3 mb-4">
              <div className="flex items-start gap-2">
                <Sparkles size={16} className="text-yellow-500 mt-0.5" />
                <p className="text-gray-300 text-sm">准备就绪，请描述您想要生成或调整的空间场景</p>
              </div>
            </div>
          </div>

          {/* Input Area */}
          <div className="p-4 border-t border-gray-800">
            <div className="bg-gray-800 rounded-lg p-3">
              <textarea
                placeholder="描述你想要的空间效果..."
                className="w-full bg-transparent text-white text-sm resize-none outline-none h-20"
              />
              <div className="flex items-center justify-between mt-2">
                <button className="text-gray-400 hover:text-white">
                  <Paperclip size={18} />
                </button>
                <div className="flex items-center gap-2">
                  <select className="bg-gray-700 text-white text-xs rounded-lg px-2 py-1 outline-none">
                    <option>NanoBanana 2</option>
                    <option>NanoBanana Pro</option>
                  </select>
                  <div className="flex gap-1">
                    {['1K', '2K', '4K'].map((res) => (
                      <button
                        key={res}
                        onClick={() => setResolution(res)}
                        className={`px-2 py-1 rounded text-xs font-medium transition-colors ${
                          resolution === res
                            ? 'bg-yellow-500 text-black'
                            : 'bg-gray-700 text-gray-400 hover:bg-gray-600'
                        }`}
                      >
                        {res}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Workspace;
