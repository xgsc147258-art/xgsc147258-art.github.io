import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus } from 'lucide-react';

const recentProjects = [
  { id: 1, title: '室内彩屏·通风分析', subtitle: '点击进入，修改提示词即可生成', tag: '万能提示词工具人', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=400&h=300&fit=crop' },
  { id: 2, title: '九宫格分镜·极简空间', subtitle: '点击进入，修改提示词即可生成', tag: '九宫格分镜师', image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=400&h=300&fit=crop' },
  { id: 3, title: '建筑效果图·鸟瞰视角', subtitle: '点击进入，修改提示词即可生成', tag: '3D鸟瞰轴测生成器', image: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=400&h=300&fit=crop' },
];

export default function HomePage() {
  const [activeTab, setActiveTab] = useState('NanoBanana 2');
  const [inputValue, setInputValue] = useState('');

  return (
    <div className="p-8">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-2">小憨熊AI研究所</h1>
          <p className="text-gray-500">空间神经引擎 / Spatial Neural Engine</p>
        </div>

        <div className="flex items-center gap-4 mb-6 max-w-2xl mx-auto">
          <div className="flex-1 flex items-center bg-white rounded-full border border-gray-200 px-4 py-3 shadow-sm">
            <div className="w-8 h-8 bg-black rounded-full flex items-center justify-center mr-3">
              <Plus size={16} className="text-white" />
            </div>
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="描述你想要的空间，例如：现代简约客厅、日式茶室..."
              className="flex-1 outline-none text-sm"
            />
          </div>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="px-6 py-3 bg-black text-white rounded-full font-medium"
          >
            生成构建
          </motion.button>
        </div>

        <div className="flex items-center justify-center gap-4 mb-10">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setActiveTab('NanoBanana 2')}
            className={`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
              activeTab === 'NanoBanana 2' ? 'bg-yellow-400 text-black' : 'bg-white text-gray-600 border border-gray-200'
            }`}
          >
            NanoBanana 2
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setActiveTab('NanoBanana Pro')}
            className={`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
              activeTab === 'NanoBanana Pro' ? 'bg-yellow-400 text-black' : 'bg-white text-gray-600 border border-gray-200'
            }`}
          >
            NanoBanana Pro
          </motion.button>
        </div>

        <div>
          <h2 className="text-xl font-bold mb-6">近期项目</h2>
          <div className="grid grid-cols-3 gap-6">
            {recentProjects.map((project) => (
              <motion.div
                key={project.id}
                whileHover={{ y: -4 }}
                className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 cursor-pointer"
              >
                <div className="relative h-48">
                  <img src={project.image} alt={project.title} className="w-full h-full object-cover" />
                  <div className="absolute top-3 left-3 px-2 py-1 bg-black/70 text-white text-xs rounded">
                    {project.tag}
                  </div>
                  <div className="absolute bottom-3 right-3 px-2 py-1 bg-white/90 text-black text-xs rounded">
                    示例项目
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-semibold mb-1">{project.title}</h3>
                  <p className="text-sm text-gray-500">{project.subtitle}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
