import React, { useState } from 'react';
import { Upload, Image as ImageIcon, ArrowRight } from 'lucide-react';

export default function Purifier() {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setUploadedImage(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleProcess = () => {
    if (!uploadedImage) return;
    setIsProcessing(true);
    setTimeout(() => setIsProcessing(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#1a1a1a] flex flex-col items-center justify-center p-8">
      <div className="text-center mb-12">
        <p className="text-yellow-500 text-xs tracking-widest mb-2">PURIFIER</p>
        <h1 className="text-white text-3xl font-bold mb-4">底图净化器</h1>
        <p className="text-gray-400 text-sm">
          上传有材质的室内/建筑图片，一键转化为干净底图，直接用于工具人生图
        </p>
      </div>

      <div className="flex items-center gap-8 mb-8">
        <div className="w-80 h-64 border-2 border-dashed border-yellow-500/50 rounded-2xl flex flex-col items-center justify-center bg-[#252525] hover:bg-[#2a2a2a] transition-colors cursor-pointer relative overflow-hidden">
          <input
            type="file"
            accept=".jpg,.png,.webp"
            onChange={handleFileUpload}
            className="absolute inset-0 opacity-0 cursor-pointer z-10"
          />
          {uploadedImage ? (
            <img src={uploadedImage} alt="uploaded" className="w-full h-full object-cover" />
          ) : (
            <>
              <div className="w-16 h-16 rounded-full bg-yellow-500/20 flex items-center justify-center mb-4">
                <Upload className="w-8 h-8 text-yellow-500" />
              </div>
              <p className="text-white font-medium mb-2">上传原图</p>
              <p className="text-gray-500 text-xs">拖拽或点击上传 · JPG / PNG / WebP</p>
            </>
          )}
        </div>

        <button
          onClick={handleProcess}
          disabled={!uploadedImage || isProcessing}
          className="w-12 h-12 rounded-full bg-yellow-500 flex items-center justify-center hover:bg-yellow-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          <ArrowRight className="w-6 h-6 text-black" />
        </button>

        <div className="w-80 h-64 border border-gray-700 rounded-2xl flex flex-col items-center justify-center bg-[#252525]">
          {isProcessing ? (
            <div className="flex flex-col items-center">
              <div className="w-8 h-8 border-2 border-yellow-500 border-t-transparent rounded-full animate-spin mb-4" />
              <p className="text-gray-400 text-sm">净化中...</p>
            </div>
          ) : (
            <>
              <div className="w-16 h-16 rounded-full bg-gray-700/50 flex items-center justify-center mb-4">
                <ImageIcon className="w-8 h-8 text-gray-500" />
              </div>
              <p className="text-gray-400 font-medium mb-2">净化结果</p>
              <p className="text-gray-600 text-xs">上传图片后点击开始净化</p>
            </>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2 px-6 py-3 bg-[#252525] rounded-full">
        <span className="text-gray-500 text-sm">适用：</span>
        <span className="text-gray-400 text-sm">SU截图 · D5渲染图 · 3DMAX效果图 · 实景照片</span>
        <span className="text-yellow-500 text-sm ml-4">不适用白模或未贴材质截图</span>
      </div>
    </div>
  );
}
