import React from 'react';
import { ArrowRight, Wand2, Palette, Camera, Lock, RefreshCw, Square, Home, Hammer, Ruler } from 'lucide-react';

const tools = [
  { id: 1, tag: 'PROMPT GEN', name: '万能提示词工具人', icon: Wand2, bg: 'bg-neutral-900', iconBg: 'bg-amber-700' },
  { id: 2, tag: 'COLOR RENDER', name: '室内彩平图生成器', icon: Palette, bg: 'bg-stone-100', iconBg: 'bg-stone-300' },
  { id: 3, tag: 'PHOTO RENDER', name: '效果图渲染师', icon: Camera, bg: 'bg-slate-800', iconBg: 'bg-slate-600' },
  { id: 4, tag: 'MATERIAL LOCK', name: '材质锁定渲染师', icon: Lock, bg: 'bg-stone-100', iconBg: 'bg-stone-300' },
  { id: 5, tag: 'STYLE TRANSFER', name: '风格迁移师', icon: RefreshCw, bg: 'bg-neutral-900', iconBg: 'bg-blue-800' },
  { id: 6, tag: 'CLAY MODEL', name: '白膜生成器', icon: Square, bg: 'bg-stone-100', iconBg: 'bg-stone-300' },
  { id: 7, tag: 'VOID FILL', name: '室内方案填充师', icon: Home, bg: 'bg-neutral-900', iconBg: 'bg-rose-800' },
  { id: 8, tag: 'JOINERY ANALYST', name: '木作功能分析师', icon: Hammer, bg: 'bg-stone-100', iconBg: 'bg-stone-300' },
  { id: 9, tag: 'INTERIOR DETAIL', name: '室内节点施工图生成器', icon: Ruler, bg: 'bg-neutral-900', iconBg: 'bg-amber-700' },
];

export default function Collaboration() {
  return (
    <div className="min-h-screen bg-white p-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold text-neutral-900 mb-3">TechLab 协作台</h1>
          <p className="text-neutral-500">选择你的 AI 协作伙伴</p>
        </div>
        
        <div className="grid grid-cols-3 gap-5">
          {tools.map((tool) => {
            const Icon = tool.icon;
            return (
              <div
                key={tool.id}
                className={`${tool.bg} rounded-2xl p-5 h-44 flex flex-col justify-between cursor-pointer transition-transform hover:scale-[1.02]`}
              >
                <div className="flex justify-between items-start">
                  <span className={`text-xs font-medium px-3 py-1 rounded-full ${tool.bg === 'bg-neutral-900' ? 'bg-neutral-800 text-white' : 'bg-white/70 text-neutral-600'}`}>
                    {tool.tag}
                  </span>
                </div>
                
                <div className="flex justify-end">
                  <div className={`w-16 h-16 ${tool.iconBg} rounded-2xl flex items-center justify-center opacity-60`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className={`font-medium ${tool.bg === 'bg-neutral-900' ? 'text-white' : 'text-neutral-900'}`}>
                    {tool.name}
                  </span>
                  <button className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${tool.bg === 'bg-neutral-900' ? 'bg-white/10 hover:bg-white/20' : 'bg-neutral-900 hover:bg-neutral-800'}`}>
                    <ArrowRight className="w-4 h-4 text-white" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
