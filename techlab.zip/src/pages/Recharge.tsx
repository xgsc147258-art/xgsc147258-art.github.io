import React from 'react';
import { motion } from 'framer-motion';
import { Zap, Check } from 'lucide-react';

const Recharge: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-4xl mx-auto">
        {/* 算力值卡片 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gray-900 rounded-2xl p-6 mb-8 text-white"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-yellow-400 rounded-xl flex items-center justify-center">
                <Zap className="w-6 h-6 text-gray-900" />
              </div>
              <div>
                <p className="text-gray-400 text-sm">当前算力值</p>
                <p className="text-3xl font-bold text-yellow-400">1800 算力</p>
                <p className="text-yellow-400/80 text-xs">算力偏低，建议及时补充</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-gray-400 text-sm">会员状态</p>
              <p className="text-white font-medium">免费用户</p>
            </div>
          </div>
        </motion.div>

        {/* TechLab Pro 个人版 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <h2 className="text-2xl font-bold text-gray-900 mb-2">TechLab Pro 个人版</h2>
          <p className="text-gray-500 mb-6">每天不到¥6，跑完一套完整空间意向图</p>

          <div className="grid grid-cols-2 gap-6">
            {/* 月付 */}
            <div className="bg-white rounded-2xl p-6 border border-gray-200">
              <p className="text-gray-500 text-sm mb-4">月付</p>
              <div className="flex items-baseline gap-1 mb-2">
                <span className="text-4xl font-bold text-gray-900">¥189</span>
                <span className="text-gray-500">/月</span>
              </div>
              <p className="text-gray-400 text-sm mb-6">随时取消，次月不再扣费</p>
              <ul className="space-y-3 mb-6">
                <li className="flex items-center gap-2 text-sm text-gray-600">
                  <Check className="w-4 h-4 text-yellow-500" />
                  每日赠送 400 算力（当天有效）
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-600">
                  <Check className="w-4 h-4 text-yellow-500" />
                  全部 17 个 AI 助手
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-600">
                  <Check className="w-4 h-4 text-yellow-500" />
                  20 个项目空间 · 充值额外 +10%
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-600">
                  <Check className="w-4 h-4 text-yellow-500" />
                  开通即送 1800 算力
                </li>
              </ul>
              <button className="w-full py-3 bg-gray-900 text-white rounded-xl font-medium hover:bg-gray-800 transition-colors">
                开通月付
              </button>
            </div>

            {/* 年付 */}
            <div className="bg-gray-900 rounded-2xl p-6 relative">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-yellow-400 text-gray-900 text-xs px-3 py-1 rounded-full font-medium">
                推荐 · 年省¥380
              </div>
              <p className="text-gray-400 text-sm mb-4">年付</p>
              <div className="flex items-baseline gap-1 mb-2">
                <span className="text-4xl font-bold text-white">¥1888</span>
                <span className="text-gray-400 line-through">¥2268</span>
              </div>
              <p className="text-gray-400 text-sm mb-6">约¥157/月 · 立省¥380</p>
              <ul className="space-y-3 mb-6">
                <li className="flex items-center gap-2 text-sm text-gray-300">
                  <Check className="w-4 h-4 text-yellow-400" />
                  每日赠送 600 算力（当天有效）
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-300">
                  <Check className="w-4 h-4 text-yellow-400" />
                  全部 17 个 AI 助手
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-300">
                  <Check className="w-4 h-4 text-yellow-400" />
                  40 个项目空间 · 充值额外 +10%
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-300">
                  <Check className="w-4 h-4 text-yellow-400" />
                  开通即送 3000 算力
                </li>
              </ul>
              <button className="w-full py-3 bg-yellow-400 text-gray-900 rounded-xl font-medium hover:bg-yellow-300 transition-colors">
                立即开通
              </button>
            </div>
          </div>

          <p className="text-center text-gray-400 text-sm mt-4">
            多人使用？<span className="text-yellow-500 cursor-pointer">查看团队版 →</span>
          </p>
        </motion.div>

        {/* 团队版 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h3 className="text-xl font-bold text-gray-900 mb-2">团队版</h3>
          <p className="text-gray-500">无需企业认证，设计师个人或小团队均可购买 · 仅支持年付</p>
        </motion.div>
      </div>
    </div>
  );
};

export default Recharge;
