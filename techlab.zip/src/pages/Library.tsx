import React, { useState } from 'react';
import { Search, FolderOpen } from 'lucide-react';

export default function Library() {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="flex-1 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-gray-900">提示词库</h1>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="搜索提示词..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-64 pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-yellow-400"
            />
          </div>
        </div>

        <div className="flex flex-col items-center justify-center py-20">
          <div className="w-20 h-20 mb-6">
            <FolderOpen className="w-full h-full text-yellow-400" strokeWidth={1.5} />
          </div>
          <p className="text-lg font-medium text-gray-900 mb-2">还没有收藏的提示词</p>
          <p className="text-sm text-gray-500">在工具人对话中长按提示词即可收藏到词库</p>
        </div>
      </div>
    </div>
  );
}
