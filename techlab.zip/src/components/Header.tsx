import React from 'react';
import { Zap, Calendar } from 'lucide-react';

interface HeaderProps {
  credits?: number;
  days?: number;
  username?: string;
  isLoggedIn?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  credits = 1800,
  days = 1,
  username = '林金达',
  isLoggedIn = true
}) => {
  const maxCredits = 2000;
  const progress = (credits / maxCredits) * 100;

  return (
    <header className="h-16 bg-white border-b border-gray-100 flex items-center justify-between px-6 fixed top-0 left-0 right-0 z-50">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 bg-black rounded-lg flex items-center justify-center">
          <svg viewBox="0 0 24 24" className="w-5 h-5 text-white" fill="currentColor">
            <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
          </svg>
        </div>
        <span className="font-semibold text-lg">TechLab.AI</span>
      </div>

      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-yellow-500" />
          <div className="w-24 h-2 bg-gray-200 rounded-full">
            <div
              className="h-full bg-yellow-400 rounded-full transition-all"
              style={{ width: `${progress}%` }}
            />
          </div>
          <span className="text-sm text-gray-600">{credits} 算力</span>
        </div>

        <div className="flex items-center gap-1 text-sm text-gray-600">
          <Calendar className="w-4 h-4" />
          <span>-- 天</span>
        </div>

        {isLoggedIn ? (
          <>
            <span className="text-sm text-gray-700">{username}</span>
            <button className="px-4 py-2 bg-black text-white text-sm rounded-full hover:bg-gray-800 transition-colors">
              升级 Pro
            </button>
          </>
        ) : (
          <button className="text-sm text-gray-700 hover:text-black transition-colors">
            登录
          </button>
        )}
      </div>
    </header>
  );
};
