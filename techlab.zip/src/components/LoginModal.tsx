import React from 'react';
import { X } from 'lucide-react';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80">
      <div className="relative flex w-[720px] h-[480px] bg-white rounded-2xl overflow-hidden">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 w-8 h-8 flex items-center justify-center text-gray-400 hover:text-gray-600 transition-colors"
        >
          <X size={20} />
        </button>

        <div className="w-[320px] bg-[#1a1a1a] flex flex-col items-center justify-center p-8">
          <div className="w-16 h-16 mb-6">
            <svg viewBox="0 0 64 64" className="w-full h-full">
              <polygon points="32,4 60,20 60,52 32,68 4,52 4,20" fill="none" stroke="white" strokeWidth="2"/>
              <polygon points="32,16 48,26 48,46 32,56 16,46 16,26" fill="white"/>
            </svg>
          </div>
          <h2 className="text-white text-2xl font-bold mb-2">TechLab.AI</h2>
          <p className="text-gray-400 text-sm mb-1">空间神经引擎</p>
          <p className="text-gray-500 text-xs">Spatial Neural Engine</p>

          <div className="mt-8 space-y-3 w-full">
            <button className="w-full py-3 border border-yellow-500 text-yellow-500 rounded-lg text-sm font-medium hover:bg-yellow-500/10 transition-colors">
              微信扫码登录
            </button>
            <button className="w-full py-3 border border-gray-600 text-gray-400 rounded-lg text-sm font-medium hover:bg-gray-800 transition-colors">
              手机号登录
            </button>
          </div>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center p-8 bg-white">
          <h3 className="text-xl font-semibold text-gray-800 mb-8">微信扫码登录</h3>

          <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center mb-4">
            <svg viewBox="0 0 24 24" className="w-10 h-10 text-gray-400" fill="currentColor">
              <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
            </svg>
          </div>
          <p className="text-gray-600 mb-6">林金达</p>

          <button className="w-full max-w-[240px] py-3 bg-[#07c160] text-white rounded-lg text-sm font-medium hover:bg-[#06ad56] transition-colors mb-4">
            微信快捷登录
          </button>

          <p className="text-gray-400 text-sm mb-8">使用其他头像、昵称或账号</p>

          <p className="text-gray-400 text-xs text-center">
            首次登录将自动注册账号
          </p>

          <div className="absolute bottom-6 left-0 right-0 text-center">
            <p className="text-gray-400 text-xs">
              登录即代表同意
              <a href="#" className="text-blue-500 hover:underline mx-1">《用户协议》</a>
              和
              <a href="#" className="text-blue-500 hover:underline mx-1">《隐私政策》</a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
